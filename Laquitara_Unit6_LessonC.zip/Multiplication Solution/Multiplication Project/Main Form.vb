﻿' Name:         Multiplication Project
' Purpose:      Display a multiplication table that shows
'               the multiplicand, multiplier, and product
' Programmer:   <Shelby Laquitara> on <04/05/2016>

Option Explicit On
Option Strict On
Option Infer Off

Public Class frmMain

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnDisplay_Click(sender As Object, e As EventArgs) Handles btnDisplay.Click
        lblTable.Text = String.Empty
        'declare the variable
        Dim Num As Integer = Convert.ToInt32(txtNumber.Text)

        'making calculation
        For intX As Integer = 1 To 9
            lblTable.Text += Num.ToString + " * " +
                intX.ToString + " = " + (Num * intX).ToString +
                ControlChars.NewLine
        Next intX
    End Sub
End Class
