﻿Public Class frmMain

    Private totalScore As Integer = 0
    Private numOfScores As Integer = 0
    Private avgScore As Double = 0
    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Me.Close()
    End Sub

    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles Me.Load
        For score As Integer = 0 To 10
            lstScore.Items.Add(score.ToString)
        Next
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        'create calculations
        Dim score As Integer = Convert.ToInt32(lstScore.SelectedItem)
        numOfScores = numOfScores + 1
        totalScore = totalScore + Convert.ToInt32(lstScore.SelectedItem)
        avgScore = totalScore / numOfScores

        'display in the textboxes
        txtNum.Text = numOfScores.ToString
        txtTotal.Text = totalScore.ToString
        txtAvg.Text = avgScore.ToString("N2")
    End Sub


    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        totalScore = 0
        numOfScores = 0
        avgScore = 0
        txtAvg.Text = String.Empty
        txtNum.Text = String.Empty
        txtTotal.Text = String.Empty
    End Sub
End Class
