﻿Public Class frmMain

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim originalPrice As Double
        Dim discountRates As Double
        Dim discountPrice As Double
        Dim amountDiscount As Double

        'Making calculations
        originalPrice = Convert.ToDouble(txtOriginal.Text)
        discountRates = Convert.ToDouble(lstDiscount.SelectedItem.TrimEnd("%").Trim)
        amountDiscount = originalPrice * discountRates / 100
        discountPrice = originalPrice - amountDiscount

        'display in the textboxes
        txtDiscountPrice.Text = discountPrice.ToString("C2")
        txtAmountDiscount.Text = amountDiscount.ToString("C2")

    End Sub

    Private Sub ListBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lstDiscount.SelectedIndexChanged
        txtAmountDiscount.Text = String.Empty
        txtDiscountPrice.Text = String.Empty
    End Sub

    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles Me.Load
        For discount As Integer = 10 To 40 Step 5
            lstDiscount.Items.Add(discount.ToString + "%")
        Next discount
    End Sub
End Class
