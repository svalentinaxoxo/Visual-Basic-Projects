﻿' Name:         Gross Pay Project
' Purpose:      Displays an employee's gross pay
' Programmer:   <Shelby Laquitara> on <04/05/2016>

Option Explicit On
Option Strict On
Option Infer Off

Public Class frmMain

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles Me.Load
        For hours As Double = 0.5 To 50.0 Step 0.5
            lstHours.Items.Add(hours.ToString)
        Next hours

        For rate As Double = 8.0 To 15.0 Step 0.5
            lstRates.Items.Add(rate.ToString)
        Next
    End Sub

    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        Dim hoursWorked As Double = Convert.ToDouble(lstHours.SelectedItem)
        Dim payRate As Double
        Dim rate As Double = Convert.ToDouble(lstRates.SelectedItem)
        If hoursWorked > 40 Then
            payRate = rate * 40 + rate * 1.5 * (hoursWorked - 40)
        Else
            payRate = hoursWorked * rate
        End If
        lblGross.Text = payRate.ToString("C2")
    End Sub
End Class
