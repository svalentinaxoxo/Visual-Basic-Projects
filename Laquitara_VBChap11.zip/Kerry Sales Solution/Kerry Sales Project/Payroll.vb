﻿' Name:         Payroll.vb
' Programmer:   <Shelby Laquitara> on <04/21/2016>


' base class
Public Class Bonus
    Private _SalesId As String
    Private _Sales As Double

    Public Property SalesId As String
        Get
            Return _SalesId
        End Get
        Set(value As String)
            _SalesId = value
        End Set
    End Property
    Public Property Sales As Double
        Get
            Return _Sales
        End Get
        Set(value As Double)
            _Sales = value
        End Set
    End Property

    'super class
    Public Sub New()
        _SalesId = ""
        _Sales = 0
    End Sub

    'parameterized
    Public Sub New(ByVal salesId As String, ByVal sales As Double)
        _SalesId = salesId
        _Sales = sales
    End Sub

    'Get bonus method
    Public Function GetBonus() As Double
        Return _Sales * 0.05
    End Function

End Class

'derived class
Public Class PremiumBonus
    Inherits Bonus
    'constructor 
    Public Sub New()
        SalesId = ""
        Sales = 0
    End Sub

    'parameterized
    Public Sub New(ByVal salesId As String, ByVal sales As Double)
        'first should be capital case
        salesId = salesId
        sales = sales
    End Sub

    Public Function GetPremiumBonus() As Double
        Return Sales * 0.05 + (Sales - 2500) * 0.01
    End Function
End Class
