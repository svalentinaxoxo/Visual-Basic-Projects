﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtIncome = New System.Windows.Forms.TextBox()
        Me.txtLower = New System.Windows.Forms.TextBox()
        Me.txtUpper = New System.Windows.Forms.TextBox()
        Me.lblIncome = New System.Windows.Forms.Label()
        Me.lblLower = New System.Windows.Forms.Label()
        Me.lblUpper = New System.Windows.Forms.Label()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'txtIncome
        '
        Me.txtIncome.Location = New System.Drawing.Point(60, 55)
        Me.txtIncome.Name = "txtIncome"
        Me.txtIncome.Size = New System.Drawing.Size(100, 20)
        Me.txtIncome.TabIndex = 0
        '
        'txtLower
        '
        Me.txtLower.Location = New System.Drawing.Point(60, 115)
        Me.txtLower.Name = "txtLower"
        Me.txtLower.ReadOnly = True
        Me.txtLower.Size = New System.Drawing.Size(100, 20)
        Me.txtLower.TabIndex = 1
        '
        'txtUpper
        '
        Me.txtUpper.Location = New System.Drawing.Point(60, 165)
        Me.txtUpper.Name = "txtUpper"
        Me.txtUpper.ReadOnly = True
        Me.txtUpper.Size = New System.Drawing.Size(100, 20)
        Me.txtUpper.TabIndex = 2
        '
        'lblIncome
        '
        Me.lblIncome.AutoSize = True
        Me.lblIncome.Location = New System.Drawing.Point(57, 39)
        Me.lblIncome.Name = "lblIncome"
        Me.lblIncome.Size = New System.Drawing.Size(136, 13)
        Me.lblIncome.TabIndex = 3
        Me.lblIncome.Text = "Enter Annual Gross Income"
        '
        'lblLower
        '
        Me.lblLower.AutoSize = True
        Me.lblLower.Location = New System.Drawing.Point(60, 96)
        Me.lblLower.Name = "lblLower"
        Me.lblLower.Size = New System.Drawing.Size(113, 13)
        Me.lblLower.TabIndex = 4
        Me.lblLower.Text = "Lower mortgage range"
        '
        'lblUpper
        '
        Me.lblUpper.AutoSize = True
        Me.lblUpper.Location = New System.Drawing.Point(60, 146)
        Me.lblUpper.Name = "lblUpper"
        Me.lblUpper.Size = New System.Drawing.Size(113, 13)
        Me.lblUpper.TabIndex = 5
        Me.lblUpper.Text = "Upper mortgage range"
        '
        'btnCalculate
        '
        Me.btnCalculate.Location = New System.Drawing.Point(237, 65)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(75, 23)
        Me.btnCalculate.TabIndex = 6
        Me.btnCalculate.Text = "Calculate"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(525, 261)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.lblUpper)
        Me.Controls.Add(Me.lblLower)
        Me.Controls.Add(Me.lblIncome)
        Me.Controls.Add(Me.txtUpper)
        Me.Controls.Add(Me.txtLower)
        Me.Controls.Add(Me.txtIncome)
        Me.Name = "frmMain"
        Me.Text = "Mortgage Calculator"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtIncome As TextBox
    Friend WithEvents txtLower As TextBox
    Friend WithEvents txtUpper As TextBox
    Friend WithEvents lblIncome As Label
    Friend WithEvents lblLower As Label
    Friend WithEvents lblUpper As Label
    Friend WithEvents btnCalculate As Button
End Class
