﻿' Name: Mortgage Solution
' Purpose: allows user to enter annual gross income 
' and displays the upper and lower ends of the mortage range. 
' Programmer: <Shelby Laquitara> on <03/30/2016>

Public Class frmMain

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Dim income As Double
        Dim lower As Double
        Dim upper As Double

        income = Convert.ToDouble(txtIncome.Text)
        lower = income * 2
        upper = income * 2.5
        txtLower.Text = lower.ToString
        txtUpper.Text = upper.ToString
    End Sub

    Private Sub txtIncome_Enter(sender As Object,
    e As EventArgs) Handles txtIncome.Enter
        txtIncome.SelectAll()
    End Sub

    Private Sub CancelKeys(sender As Object, e As KeyPressEventArgs
                           ) Handles txtIncome.KeyPress
        If (e.KeyChar < "0" OrElse e.KeyChar > "9") AndAlso
            e.KeyChar <> ControlChars.Back AndAlso
            e.KeyChar <> "." Then
            e.Handled = True
        End If
    End Sub
End Class
