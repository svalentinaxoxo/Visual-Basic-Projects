﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtOwed = New System.Windows.Forms.TextBox()
        Me.txtPaid = New System.Windows.Forms.TextBox()
        Me.txtDue = New System.Windows.Forms.TextBox()
        Me.lblOwes = New System.Windows.Forms.Label()
        Me.lblPaid = New System.Windows.Forms.Label()
        Me.lblChange = New System.Windows.Forms.Label()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'txtOwed
        '
        Me.txtOwed.Location = New System.Drawing.Point(62, 52)
        Me.txtOwed.Name = "txtOwed"
        Me.txtOwed.Size = New System.Drawing.Size(100, 20)
        Me.txtOwed.TabIndex = 0
        '
        'txtPaid
        '
        Me.txtPaid.Location = New System.Drawing.Point(62, 122)
        Me.txtPaid.Name = "txtPaid"
        Me.txtPaid.Size = New System.Drawing.Size(100, 20)
        Me.txtPaid.TabIndex = 1
        '
        'txtDue
        '
        Me.txtDue.Location = New System.Drawing.Point(62, 192)
        Me.txtDue.Name = "txtDue"
        Me.txtDue.ReadOnly = True
        Me.txtDue.Size = New System.Drawing.Size(100, 20)
        Me.txtDue.TabIndex = 2
        '
        'lblOwes
        '
        Me.lblOwes.AutoSize = True
        Me.lblOwes.Location = New System.Drawing.Point(62, 33)
        Me.lblOwes.Name = "lblOwes"
        Me.lblOwes.Size = New System.Drawing.Size(74, 13)
        Me.lblOwes.TabIndex = 3
        Me.lblOwes.Text = "Amount Owed"
        '
        'lblPaid
        '
        Me.lblPaid.AutoSize = True
        Me.lblPaid.Location = New System.Drawing.Point(62, 103)
        Me.lblPaid.Name = "lblPaid"
        Me.lblPaid.Size = New System.Drawing.Size(67, 13)
        Me.lblPaid.TabIndex = 4
        Me.lblPaid.Text = "Amount Paid"
        '
        'lblChange
        '
        Me.lblChange.AutoSize = True
        Me.lblChange.Location = New System.Drawing.Point(59, 176)
        Me.lblChange.Name = "lblChange"
        Me.lblChange.Size = New System.Drawing.Size(68, 13)
        Me.lblChange.TabIndex = 5
        Me.lblChange.Text = "Change due "
        '
        'btnCalculate
        '
        Me.btnCalculate.Location = New System.Drawing.Point(242, 52)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(75, 23)
        Me.btnCalculate.TabIndex = 6
        Me.btnCalculate.Text = "calculate"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(455, 261)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.lblChange)
        Me.Controls.Add(Me.lblPaid)
        Me.Controls.Add(Me.lblOwes)
        Me.Controls.Add(Me.txtDue)
        Me.Controls.Add(Me.txtPaid)
        Me.Controls.Add(Me.txtOwed)
        Me.Name = "frmMain"
        Me.Text = "Hinsbrook Project"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtOwed As TextBox
    Friend WithEvents txtPaid As TextBox
    Friend WithEvents txtDue As TextBox
    Friend WithEvents lblOwes As Label
    Friend WithEvents lblPaid As Label
    Friend WithEvents lblChange As Label
    Friend WithEvents btnCalculate As Button
End Class
