﻿' Name: Modified Hinsbrook Solution
' Purpose: Adds the change due to the solution in dollars, 
' quarters, dimes, and pennies.
' Programmer: <Shelby Laquitara> on <03/30/2016>
Public Class frmMain

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        'declaring variables
        Dim owed As Double = Convert.ToDouble(txtOwed.Text)
        Dim paid As Double = Convert.ToDouble(txtPaid.Text)
        Dim ChangeDue As Double

        'making calculation and if statement with message box 
        If paid >= owed Then
            ChangeDue = paid - owed
            txtDue.Text = ChangeDue.ToString
            ChangeDue = ChangeDue * 100
            'declaring the change as variables 
            Dim dollars As Integer
            Dim quarters As Integer
            Dim dimes As Integer
            Dim nickels As Integer
            'calculating the change in dollars
            dollars = ChangeDue \ 100
            txtDollars.Text = dollars.ToString("N2")
            ChangeDue = ChangeDue - dollars * 100
            'calculating the change in quarters
            quarters = ChangeDue \ 25
            txtQuarters.Text = quarters.ToString("N2")
            ChangeDue = ChangeDue - quarters * 25
            'calculating the change in Dimes
            dimes = ChangeDue \ 10
            txtDimes.Text = dimes.ToString("N2")
            ChangeDue = ChangeDue - dimes * 10
            'calculating the change in nickels
            nickels = ChangeDue \ 5
            txtNickels.Text = nickels.ToString("N2")
            ChangeDue = ChangeDue - nickels * 5
            'calculating the change in pennies
            txtPennies.Text = ChangeDue.ToString("N2")
        Else
            MessageBox.Show("The amount paid is less than the amount owed.", "Hinsbrook", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End If
    End Sub
    'highlight when selected Owed
    Private Sub txtOwed_Enter(sender As Object,
    e As EventArgs) Handles txtOwed.Enter
        txtOwed.SelectAll()
    End Sub
    'highlight when selected Paid
    Private Sub txtPaid_Enter(sender As Object,
    e As EventArgs) Handles txtPaid.Enter
        txtPaid.SelectAll()
    End Sub
    'will only allow numbers, back space, and the period
    Private Sub CancelKeys(sender As Object, e As KeyPressEventArgs
                               ) Handles txtOwed.KeyPress, txtPaid.KeyPress
        If (e.KeyChar < "0" OrElse e.KeyChar > "9") AndAlso
            e.KeyChar <> ControlChars.Back AndAlso
            e.KeyChar <> "." Then
            e.Handled = True
        End If
    End Sub
End Class
