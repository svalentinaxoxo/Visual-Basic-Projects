﻿Public Class frmMain
    Private yearExpenses As Double = 0
    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        Dim monthExpenses As Double
        monthExpenses = Convert.ToDouble(txtLoan.Text) + Convert.ToDouble(txtInsurance.Text) +
        Convert.ToDouble(txtOil.Text) + Convert.ToDouble(txtMaintenance.Text) +
            Convert.ToDouble(txtWashes.Text) + Convert.ToDouble(txtGas.Text)
        yearExpenses += monthExpenses
        txtMonthly.Text = monthExpenses.ToString 'display in the textbox 
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        txtYearly.Text = yearExpenses.ToString
    End Sub
End Class
