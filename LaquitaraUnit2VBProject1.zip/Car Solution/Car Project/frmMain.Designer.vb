﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtLoan = New System.Windows.Forms.TextBox()
        Me.txtInsurance = New System.Windows.Forms.TextBox()
        Me.txtOil = New System.Windows.Forms.TextBox()
        Me.txtGas = New System.Windows.Forms.TextBox()
        Me.txtMaintenance = New System.Windows.Forms.TextBox()
        Me.txtWashes = New System.Windows.Forms.TextBox()
        Me.txtMonthly = New System.Windows.Forms.TextBox()
        Me.txtYearly = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.btnCalc = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'txtLoan
        '
        Me.txtLoan.Location = New System.Drawing.Point(21, 54)
        Me.txtLoan.Name = "txtLoan"
        Me.txtLoan.Size = New System.Drawing.Size(100, 20)
        Me.txtLoan.TabIndex = 0
        '
        'txtInsurance
        '
        Me.txtInsurance.Location = New System.Drawing.Point(176, 54)
        Me.txtInsurance.Name = "txtInsurance"
        Me.txtInsurance.Size = New System.Drawing.Size(100, 20)
        Me.txtInsurance.TabIndex = 1
        '
        'txtOil
        '
        Me.txtOil.Location = New System.Drawing.Point(337, 54)
        Me.txtOil.Name = "txtOil"
        Me.txtOil.Size = New System.Drawing.Size(100, 20)
        Me.txtOil.TabIndex = 2
        '
        'txtGas
        '
        Me.txtGas.Location = New System.Drawing.Point(337, 117)
        Me.txtGas.Name = "txtGas"
        Me.txtGas.Size = New System.Drawing.Size(100, 20)
        Me.txtGas.TabIndex = 3
        '
        'txtMaintenance
        '
        Me.txtMaintenance.Location = New System.Drawing.Point(24, 106)
        Me.txtMaintenance.Name = "txtMaintenance"
        Me.txtMaintenance.Size = New System.Drawing.Size(100, 20)
        Me.txtMaintenance.TabIndex = 4
        '
        'txtWashes
        '
        Me.txtWashes.Location = New System.Drawing.Point(176, 106)
        Me.txtWashes.Name = "txtWashes"
        Me.txtWashes.Size = New System.Drawing.Size(100, 20)
        Me.txtWashes.TabIndex = 5
        '
        'txtMonthly
        '
        Me.txtMonthly.Location = New System.Drawing.Point(176, 162)
        Me.txtMonthly.Name = "txtMonthly"
        Me.txtMonthly.ReadOnly = True
        Me.txtMonthly.Size = New System.Drawing.Size(100, 20)
        Me.txtMonthly.TabIndex = 6
        '
        'txtYearly
        '
        Me.txtYearly.Location = New System.Drawing.Point(176, 220)
        Me.txtYearly.Name = "txtYearly"
        Me.txtYearly.ReadOnly = True
        Me.txtYearly.Size = New System.Drawing.Size(100, 20)
        Me.txtYearly.TabIndex = 7
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(19, 29)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(0, 13)
        Me.Label1.TabIndex = 10
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(19, 38)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(70, 13)
        Me.Label2.TabIndex = 11
        Me.Label2.Text = "loan payment"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(173, 38)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(53, 13)
        Me.Label3.TabIndex = 12
        Me.Label3.Text = "insurance"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(337, 38)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(56, 13)
        Me.Label4.TabIndex = 13
        Me.Label4.Text = "oil change"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(21, 90)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(68, 13)
        Me.Label5.TabIndex = 14
        Me.Label5.Text = "maintenance"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(184, 90)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(61, 13)
        Me.Label6.TabIndex = 15
        Me.Label6.Text = "car washes"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(337, 90)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(24, 13)
        Me.Label7.TabIndex = 16
        Me.Label7.Text = "gas"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(173, 146)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(114, 13)
        Me.Label8.TabIndex = 17
        Me.Label8.Text = "month's total expenses"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(173, 204)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(105, 13)
        Me.Label9.TabIndex = 18
        Me.Label9.Text = "year's total expenses"
        '
        'btnCalc
        '
        Me.btnCalc.Location = New System.Drawing.Point(21, 156)
        Me.btnCalc.Name = "btnCalc"
        Me.btnCalc.Size = New System.Drawing.Size(138, 23)
        Me.btnCalc.TabIndex = 19
        Me.btnCalc.Text = "Calculate Month Total:"
        Me.btnCalc.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(24, 217)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(135, 23)
        Me.Button1.TabIndex = 20
        Me.Button1.Text = "Calculate Yearly Total:"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(696, 261)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.btnCalc)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtYearly)
        Me.Controls.Add(Me.txtMonthly)
        Me.Controls.Add(Me.txtWashes)
        Me.Controls.Add(Me.txtMaintenance)
        Me.Controls.Add(Me.txtGas)
        Me.Controls.Add(Me.txtOil)
        Me.Controls.Add(Me.txtInsurance)
        Me.Controls.Add(Me.txtLoan)
        Me.Name = "frmMain"
        Me.Text = "Car Expense Calculator"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtLoan As TextBox
    Friend WithEvents txtInsurance As TextBox
    Friend WithEvents txtOil As TextBox
    Friend WithEvents txtGas As TextBox
    Friend WithEvents txtMaintenance As TextBox
    Friend WithEvents txtWashes As TextBox
    Friend WithEvents txtMonthly As TextBox
    Friend WithEvents txtYearly As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents btnCalc As Button
    Friend WithEvents Button1 As Button
End Class
