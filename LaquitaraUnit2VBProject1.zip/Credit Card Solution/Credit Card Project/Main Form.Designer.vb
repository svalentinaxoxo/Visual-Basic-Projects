﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtMerch = New System.Windows.Forms.TextBox()
        Me.txtRest = New System.Windows.Forms.TextBox()
        Me.txtGas = New System.Windows.Forms.TextBox()
        Me.txtTravel = New System.Windows.Forms.TextBox()
        Me.txtServices = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtSuper = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.TxtMonthly = New System.Windows.Forms.TextBox()
        Me.txtYearly = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.txtMerch2 = New System.Windows.Forms.TextBox()
        Me.txtRest2 = New System.Windows.Forms.TextBox()
        Me.txtGas2 = New System.Windows.Forms.TextBox()
        Me.txtTravel2 = New System.Windows.Forms.TextBox()
        Me.txtServices2 = New System.Windows.Forms.TextBox()
        Me.txtSuper2 = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'txtMerch
        '
        Me.txtMerch.Location = New System.Drawing.Point(31, 74)
        Me.txtMerch.Name = "txtMerch"
        Me.txtMerch.Size = New System.Drawing.Size(100, 20)
        Me.txtMerch.TabIndex = 0
        '
        'txtRest
        '
        Me.txtRest.Location = New System.Drawing.Point(174, 74)
        Me.txtRest.Name = "txtRest"
        Me.txtRest.Size = New System.Drawing.Size(100, 20)
        Me.txtRest.TabIndex = 1
        '
        'txtGas
        '
        Me.txtGas.Location = New System.Drawing.Point(315, 74)
        Me.txtGas.Name = "txtGas"
        Me.txtGas.Size = New System.Drawing.Size(100, 20)
        Me.txtGas.TabIndex = 2
        '
        'txtTravel
        '
        Me.txtTravel.Location = New System.Drawing.Point(31, 145)
        Me.txtTravel.Name = "txtTravel"
        Me.txtTravel.Size = New System.Drawing.Size(100, 20)
        Me.txtTravel.TabIndex = 3
        '
        'txtServices
        '
        Me.txtServices.Location = New System.Drawing.Point(174, 145)
        Me.txtServices.Name = "txtServices"
        Me.txtServices.Size = New System.Drawing.Size(100, 20)
        Me.txtServices.TabIndex = 4
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(28, 58)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(68, 13)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "Merchandise"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(174, 58)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(64, 13)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "Restaurants"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(315, 55)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(48, 13)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "Gasoline"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(31, 126)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(107, 13)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "Travel/Entertainment"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(174, 126)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(48, 13)
        Me.Label5.TabIndex = 9
        Me.Label5.Text = "Services"
        '
        'txtSuper
        '
        Me.txtSuper.Location = New System.Drawing.Point(318, 145)
        Me.txtSuper.Name = "txtSuper"
        Me.txtSuper.Size = New System.Drawing.Size(100, 20)
        Me.txtSuper.TabIndex = 10
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(318, 125)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(72, 13)
        Me.Label6.TabIndex = 11
        Me.Label6.Text = "Supermarkets"
        '
        'TxtMonthly
        '
        Me.TxtMonthly.Location = New System.Drawing.Point(157, 211)
        Me.TxtMonthly.Name = "TxtMonthly"
        Me.TxtMonthly.ReadOnly = True
        Me.TxtMonthly.Size = New System.Drawing.Size(100, 20)
        Me.TxtMonthly.TabIndex = 12
        '
        'txtYearly
        '
        Me.txtYearly.Location = New System.Drawing.Point(396, 210)
        Me.txtYearly.Name = "txtYearly"
        Me.txtYearly.ReadOnly = True
        Me.txtYearly.Size = New System.Drawing.Size(100, 20)
        Me.txtYearly.TabIndex = 13
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(31, 208)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(107, 23)
        Me.Button1.TabIndex = 14
        Me.Button1.Text = "Calculate Monthly Charges"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(154, 189)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(86, 13)
        Me.Label8.TabIndex = 16
        Me.Label8.Text = "Monthly Charges"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(393, 189)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(78, 13)
        Me.Label9.TabIndex = 17
        Me.Label9.Text = "Yearly Charges"
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(275, 208)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(104, 23)
        Me.Button2.TabIndex = 18
        Me.Button2.Text = "Calculate Yearly"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'txtMerch2
        '
        Me.txtMerch2.Location = New System.Drawing.Point(31, 328)
        Me.txtMerch2.Name = "txtMerch2"
        Me.txtMerch2.ReadOnly = True
        Me.txtMerch2.Size = New System.Drawing.Size(100, 20)
        Me.txtMerch2.TabIndex = 19
        '
        'txtRest2
        '
        Me.txtRest2.Location = New System.Drawing.Point(174, 328)
        Me.txtRest2.Name = "txtRest2"
        Me.txtRest2.ReadOnly = True
        Me.txtRest2.Size = New System.Drawing.Size(100, 20)
        Me.txtRest2.TabIndex = 20
        '
        'txtGas2
        '
        Me.txtGas2.Location = New System.Drawing.Point(315, 328)
        Me.txtGas2.Name = "txtGas2"
        Me.txtGas2.ReadOnly = True
        Me.txtGas2.Size = New System.Drawing.Size(100, 20)
        Me.txtGas2.TabIndex = 21
        '
        'txtTravel2
        '
        Me.txtTravel2.Location = New System.Drawing.Point(31, 385)
        Me.txtTravel2.Name = "txtTravel2"
        Me.txtTravel2.ReadOnly = True
        Me.txtTravel2.Size = New System.Drawing.Size(100, 20)
        Me.txtTravel2.TabIndex = 22
        '
        'txtServices2
        '
        Me.txtServices2.Location = New System.Drawing.Point(174, 385)
        Me.txtServices2.Name = "txtServices2"
        Me.txtServices2.ReadOnly = True
        Me.txtServices2.Size = New System.Drawing.Size(100, 20)
        Me.txtServices2.TabIndex = 23
        '
        'txtSuper2
        '
        Me.txtSuper2.Location = New System.Drawing.Point(315, 385)
        Me.txtSuper2.Name = "txtSuper2"
        Me.txtSuper2.ReadOnly = True
        Me.txtSuper2.Size = New System.Drawing.Size(100, 20)
        Me.txtSuper2.TabIndex = 24
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(28, 312)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(68, 13)
        Me.Label7.TabIndex = 25
        Me.Label7.Text = "Merchandise"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(171, 312)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(64, 13)
        Me.Label10.TabIndex = 26
        Me.Label10.Text = "Restaurants"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(318, 312)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(48, 13)
        Me.Label11.TabIndex = 27
        Me.Label11.Text = "Gasoline"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(28, 369)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(107, 13)
        Me.Label12.TabIndex = 28
        Me.Label12.Text = "Travel/Entertainment"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(171, 369)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(48, 13)
        Me.Label13.TabIndex = 29
        Me.Label13.Text = "Services"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(315, 369)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(72, 13)
        Me.Label14.TabIndex = 30
        Me.Label14.Text = "Supermarkets"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(142, 277)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(157, 18)
        Me.Label15.TabIndex = 31
        Me.Label15.Text = "Annual Percentages"
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(543, 436)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.txtSuper2)
        Me.Controls.Add(Me.txtServices2)
        Me.Controls.Add(Me.txtTravel2)
        Me.Controls.Add(Me.txtGas2)
        Me.Controls.Add(Me.txtRest2)
        Me.Controls.Add(Me.txtMerch2)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.txtYearly)
        Me.Controls.Add(Me.TxtMonthly)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.txtSuper)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtServices)
        Me.Controls.Add(Me.txtTravel)
        Me.Controls.Add(Me.txtGas)
        Me.Controls.Add(Me.txtRest)
        Me.Controls.Add(Me.txtMerch)
        Me.Name = "frmMain"
        Me.Text = "Credit Card Calculator"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtMerch As TextBox
    Friend WithEvents txtRest As TextBox
    Friend WithEvents txtGas As TextBox
    Friend WithEvents txtTravel As TextBox
    Friend WithEvents txtServices As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents txtSuper As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents TxtMonthly As TextBox
    Friend WithEvents txtYearly As TextBox
    Friend WithEvents Button1 As Button
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Button2 As Button
    Friend WithEvents txtMerch2 As TextBox
    Friend WithEvents txtRest2 As TextBox
    Friend WithEvents txtGas2 As TextBox
    Friend WithEvents txtTravel2 As TextBox
    Friend WithEvents txtServices2 As TextBox
    Friend WithEvents txtSuper2 As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label15 As Label
End Class
