﻿Public Class frmMain
    Private yearlyExpenses As Double = 0
    Private gasTotal As Double = 0
    Private merchTotal As Double = 0
    Private restTotal As Double = 0
    Private servicesTotal As Double = 0
    Private superTotal As Double = 0
    Private travelTotal As Double = 0

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim monthlyExpenses As Double
        monthlyExpenses = Convert.ToDouble(txtGas.Text) +
            Convert.ToDouble(txtMerch.Text) + Convert.ToDouble(txtTravel.Text) +
            Convert.ToDouble(txtRest.Text) + Convert.ToDouble(txtServices.Text) +
            Convert.ToDouble(txtSuper.Text)
        yearlyExpenses += monthlyExpenses
        TxtMonthly.Text = monthlyExpenses.ToString
        gasTotal += Convert.ToDouble(txtGas.Text) 'getting the total based off what user entered
        merchTotal += Convert.ToDouble(txtMerch.Text)
        restTotal += Convert.ToDouble(txtRest.Text)
        servicesTotal += Convert.ToDouble(txtServices.Text)
        superTotal += Convert.ToDouble(txtSuper.Text)
        travelTotal += Convert.ToDouble(txtTravel.Text)
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        txtYearly.Text = yearlyExpenses.ToString
        txtGas2.Text = (gasTotal * 100 / yearlyExpenses).ToString("N2")
        txtMerch2.Text = (merchTotal * 100 / yearlyExpenses).ToString("N2")
        txtRest2.Text = (restTotal * 100 / yearlyExpenses).ToString("N2")
        txtServices2.Text = (servicesTotal * 100 / yearlyExpenses).ToString("N2")
        txtSuper2.Text = (superTotal * 100 / yearlyExpenses).ToString("N2")
        txtTravel2.Text = (travelTotal * 100 / yearlyExpenses).ToString("N2")
    End Sub

    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
