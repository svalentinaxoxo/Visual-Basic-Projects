﻿Public Class frmMain
    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim dollars As Integer
        Dim quarters As Integer
        Dim dimes As Integer
        Dim nickels As Integer
        Dim value As Integer

        value = Convert.ToInt32(txtValue.Text)
        dollars = value \ 100
        lblDollars.Text = dollars.ToString
        value = value - dollars * 100

        quarters = value \ 25
        lblQuarters.Text = quarters.ToString
        value = value - quarters * 25

        dimes = value \ 10
        lblDimes.Text = dimes.ToString
        value = value - dimes * 10

        nickels = value \ 5
        lblNickels.Text = nickels.ToString
        value = value - nickels * 5

        lblPennies.Text = value.ToString
    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()
    End Sub

    Private Sub txtValue_TextChanged(sender As Object, e As EventArgs) Handles txtValue.TextChanged
        lblDimes.Text = String.Empty
        lblDollars.Text = String.Empty
        lblNickels.Text = String.Empty
        lblPennies.Text = String.Empty
        lblQuarters.Text = String.Empty
    End Sub
End Class
