﻿' Name:         CityState Project
' Purpose:      Displays the city name followed by a comma,
'               a space, and the state name
' Programmer:   <your name> on <current date>

Option Explicit On
Option Strict On
Option Infer Off

Public Class frmMain
    Private strState As String
    Private strCity As String

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles Me.Load
        strCity = InputBox("Please enter the City:")
        strState = InputBox("Please enter the State")

    End Sub

    Private Sub btnDisplay_Click(sender As Object, e As EventArgs) Handles btnDisplay.Click
        lblCityState.Text = strCity + ", " + strState
    End Sub
End Class
