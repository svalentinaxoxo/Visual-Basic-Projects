﻿Public Class frmMain
    Private Const TOEURO As Double = 0.89
    Private Const TOFRANC As Double = 0.97
    Private Const TORAND As Double = 15.2

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnConvert.Click
        Dim dblValue As Double
        dblValue = Convert.ToDouble(txtAmount.Text)
        lblEuro.Text = (dblValue * TOEURO).ToString("N2")
        lblFranc.Text = (dblValue * TOFRANC).ToString("N2")
        lblRand.Text = (dblValue * TORAND).ToString("N2")
    End Sub

    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()
    End Sub

    Private Sub txtAmount_TextChanged(sender As Object, e As EventArgs) Handles txtAmount.TextChanged
        lblEuro.Text = String.Empty 'clearing the control
        lblFranc.Text = String.Empty
        lblRand.Text = String.Empty

    End Sub
End Class
