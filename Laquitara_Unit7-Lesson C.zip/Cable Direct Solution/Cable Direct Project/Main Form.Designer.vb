﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lstPremium = New System.Windows.Forms.ListBox()
        Me.lstConnections = New System.Windows.Forms.ListBox()
        Me.radBusiness = New System.Windows.Forms.RadioButton()
        Me.radResidential = New System.Windows.Forms.RadioButton()
        Me.lblTotalDue = New System.Windows.Forms.Label()
        Me.txtTotalDue = New System.Windows.Forms.TextBox()
        Me.btnCalc = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.lblChannels = New System.Windows.Forms.Label()
        Me.lblConnections = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'lstPremium
        '
        Me.lstPremium.FormattingEnabled = True
        Me.lstPremium.Location = New System.Drawing.Point(297, 67)
        Me.lstPremium.Name = "lstPremium"
        Me.lstPremium.Size = New System.Drawing.Size(87, 134)
        Me.lstPremium.TabIndex = 0
        '
        'lstConnections
        '
        Me.lstConnections.FormattingEnabled = True
        Me.lstConnections.Location = New System.Drawing.Point(426, 67)
        Me.lstConnections.Name = "lstConnections"
        Me.lstConnections.Size = New System.Drawing.Size(93, 134)
        Me.lstConnections.TabIndex = 1
        '
        'radBusiness
        '
        Me.radBusiness.AutoSize = True
        Me.radBusiness.Location = New System.Drawing.Point(46, 58)
        Me.radBusiness.Name = "radBusiness"
        Me.radBusiness.Size = New System.Drawing.Size(67, 17)
        Me.radBusiness.TabIndex = 2
        Me.radBusiness.TabStop = True
        Me.radBusiness.Text = "&Business"
        Me.radBusiness.UseVisualStyleBackColor = True
        '
        'radResidential
        '
        Me.radResidential.AutoSize = True
        Me.radResidential.Location = New System.Drawing.Point(46, 94)
        Me.radResidential.Name = "radResidential"
        Me.radResidential.Size = New System.Drawing.Size(77, 17)
        Me.radResidential.TabIndex = 3
        Me.radResidential.TabStop = True
        Me.radResidential.Text = "&Residential"
        Me.radResidential.UseVisualStyleBackColor = True
        '
        'lblTotalDue
        '
        Me.lblTotalDue.AutoSize = True
        Me.lblTotalDue.Location = New System.Drawing.Point(46, 197)
        Me.lblTotalDue.Name = "lblTotalDue"
        Me.lblTotalDue.Size = New System.Drawing.Size(55, 13)
        Me.lblTotalDue.TabIndex = 4
        Me.lblTotalDue.Text = "Total due:"
        Me.lblTotalDue.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'txtTotalDue
        '
        Me.txtTotalDue.Location = New System.Drawing.Point(49, 222)
        Me.txtTotalDue.Multiline = True
        Me.txtTotalDue.Name = "txtTotalDue"
        Me.txtTotalDue.ReadOnly = True
        Me.txtTotalDue.Size = New System.Drawing.Size(100, 36)
        Me.txtTotalDue.TabIndex = 5
        '
        'btnCalc
        '
        Me.btnCalc.Location = New System.Drawing.Point(199, 222)
        Me.btnCalc.Name = "btnCalc"
        Me.btnCalc.Size = New System.Drawing.Size(132, 36)
        Me.btnCalc.TabIndex = 6
        Me.btnCalc.Text = "Calculate Total &Due"
        Me.btnCalc.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(337, 222)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(102, 36)
        Me.btnExit.TabIndex = 7
        Me.btnExit.Text = "E&xit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'lblChannels
        '
        Me.lblChannels.AutoSize = True
        Me.lblChannels.Location = New System.Drawing.Point(297, 48)
        Me.lblChannels.Name = "lblChannels"
        Me.lblChannels.Size = New System.Drawing.Size(96, 13)
        Me.lblChannels.TabIndex = 8
        Me.lblChannels.Text = "&Premium channels:"
        '
        'lblConnections
        '
        Me.lblConnections.AutoSize = True
        Me.lblConnections.Location = New System.Drawing.Point(426, 48)
        Me.lblConnections.Name = "lblConnections"
        Me.lblConnections.Size = New System.Drawing.Size(69, 13)
        Me.lblConnections.TabIndex = 9
        Me.lblConnections.Text = "&Connections:"
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(531, 297)
        Me.Controls.Add(Me.lblConnections)
        Me.Controls.Add(Me.lblChannels)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnCalc)
        Me.Controls.Add(Me.txtTotalDue)
        Me.Controls.Add(Me.lblTotalDue)
        Me.Controls.Add(Me.radResidential)
        Me.Controls.Add(Me.radBusiness)
        Me.Controls.Add(Me.lstConnections)
        Me.Controls.Add(Me.lstPremium)
        Me.Name = "frmMain"
        Me.Text = "Cable Direct"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lstPremium As ListBox
    Friend WithEvents lstConnections As ListBox
    Friend WithEvents radBusiness As RadioButton
    Friend WithEvents radResidential As RadioButton
    Friend WithEvents lblTotalDue As Label
    Friend WithEvents txtTotalDue As TextBox
    Friend WithEvents btnCalc As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents lblChannels As Label
    Friend WithEvents lblConnections As Label
End Class
