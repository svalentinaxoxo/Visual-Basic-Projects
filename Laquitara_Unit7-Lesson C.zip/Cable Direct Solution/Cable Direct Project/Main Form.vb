﻿' Name:         Cable Direct Solution
' Purpose:      Calculate and display total due for Cable Services based on business or residential, 
'               premium channels and connections. 
' Programmer:   <Shelby Laquitara> on <04/07/2016

Option Explicit On
Option Strict On
Option Infer Off

Public Class frmMain
    Private Function CalcBusinessTotalDue(ByVal premiumChannels As Integer, ByVal connections As Integer) As Double
        Const busProcessing As Double = 16.5
        Const busFirst10Connections As Double = 80
        Const busAdditional As Double = 4
        Const busPremium As Double = 50
        Dim busBasic As Double

        If connections <= 10 Then
            busBasic = busFirst10Connections
        Else
            busBasic = busFirst10Connections _
            + ((connections - 10) * busAdditional)
        End If

        Return busProcessing + busBasic + busPremium * premiumChannels
    End Function

    Private Function CalcResidentialTotalDue(ByVal premiumChannels As Integer) As Double
        Const resProcessing As Double = 4.5D
        Const resBasic As Double = 30
        Const resPremium As Double = 5

        Return resProcessing + resBasic + resPremium * premiumChannels
    End Function

    Private Sub ClearTotalDue(ByVal sender As Object, ByVal e As System.EventArgs) Handles radBusiness.Click, radResidential.Click, lstPremium.SelectedValueChanged, lstConnections.SelectedValueChanged
        txtTotalDue.Text = String.Empty
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        Dim TotalDue As Double = 0
        Dim premiumChannels As Integer = Convert.ToInt32(lstPremium.SelectedItem)
        Dim connections As Integer = Convert.ToInt32(lstConnections.SelectedItem)

        If radBusiness.Checked Then
            TotalDue = CalcResidentialTotalDue(premiumChannels)
        Else
            TotalDue = CalcBusinessTotalDue(premiumChannels, connections)
        End If
        'display in textbox
        txtTotalDue.Text = TotalDue.ToString("C2")
    End Sub

    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles Me.Load
        For premiumChannel As Integer = 1 To 20
            lstPremium.Items.Add(premiumChannel.ToString)
        Next premiumChannel

        For connections As Integer = 1 To 100
            lstConnections.Items.Add(connections.ToString)
        Next connections

        'select first item in each list box
        lstPremium.SelectedIndex = 0
        lstConnections.SelectedIndex = 0
    End Sub

    Private Sub frmMain_Closing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing

        Dim dlgButton As DialogResult
        dlgButton = MessageBox.Show("Are you sure you want to leave this page?", "Cable Direct Solution",
                                    MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation)
        If dlgButton = System.Windows.Forms.DialogResult.No Then
            e.Cancel = True
        End If
    End Sub
End Class