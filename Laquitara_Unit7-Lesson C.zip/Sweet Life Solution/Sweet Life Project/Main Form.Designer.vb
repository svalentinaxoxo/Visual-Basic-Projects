﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMain))
        Me.grbDoughnut = New System.Windows.Forms.GroupBox()
        Me.grbCoffee = New System.Windows.Forms.GroupBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.radGlazed = New System.Windows.Forms.RadioButton()
        Me.radSugar = New System.Windows.Forms.RadioButton()
        Me.radChocolate = New System.Windows.Forms.RadioButton()
        Me.radFilled = New System.Windows.Forms.RadioButton()
        Me.radNone = New System.Windows.Forms.RadioButton()
        Me.radRegular = New System.Windows.Forms.RadioButton()
        Me.radCapp = New System.Windows.Forms.RadioButton()
        Me.lblSubtotal = New System.Windows.Forms.Label()
        Me.lblSalesTax = New System.Windows.Forms.Label()
        Me.lblTotalDue = New System.Windows.Forms.Label()
        Me.txtSubtotal = New System.Windows.Forms.TextBox()
        Me.txtTax = New System.Windows.Forms.TextBox()
        Me.txtTotalDue = New System.Windows.Forms.TextBox()
        Me.grbDoughnut.SuspendLayout()
        Me.grbCoffee.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'grbDoughnut
        '
        Me.grbDoughnut.Controls.Add(Me.radFilled)
        Me.grbDoughnut.Controls.Add(Me.radChocolate)
        Me.grbDoughnut.Controls.Add(Me.radSugar)
        Me.grbDoughnut.Controls.Add(Me.radGlazed)
        Me.grbDoughnut.Location = New System.Drawing.Point(13, 33)
        Me.grbDoughnut.Name = "grbDoughnut"
        Me.grbDoughnut.Size = New System.Drawing.Size(158, 114)
        Me.grbDoughnut.TabIndex = 0
        Me.grbDoughnut.TabStop = False
        Me.grbDoughnut.Text = "Doughnut Choices"
        '
        'grbCoffee
        '
        Me.grbCoffee.Controls.Add(Me.radCapp)
        Me.grbCoffee.Controls.Add(Me.radRegular)
        Me.grbCoffee.Controls.Add(Me.radNone)
        Me.grbCoffee.Location = New System.Drawing.Point(13, 169)
        Me.grbCoffee.Name = "grbCoffee"
        Me.grbCoffee.Size = New System.Drawing.Size(158, 122)
        Me.grbCoffee.TabIndex = 1
        Me.grbCoffee.TabStop = False
        Me.grbCoffee.Text = "Coffee choices"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.txtTotalDue)
        Me.GroupBox3.Controls.Add(Me.txtTax)
        Me.GroupBox3.Controls.Add(Me.txtSubtotal)
        Me.GroupBox3.Controls.Add(Me.lblTotalDue)
        Me.GroupBox3.Controls.Add(Me.lblSalesTax)
        Me.GroupBox3.Controls.Add(Me.lblSubtotal)
        Me.GroupBox3.Location = New System.Drawing.Point(244, 138)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(164, 116)
        Me.GroupBox3.TabIndex = 2
        Me.GroupBox3.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(244, 33)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(164, 87)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 3
        Me.PictureBox1.TabStop = False
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(244, 267)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 4
        Me.Button1.Text = "&Calculate"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(341, 267)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 23)
        Me.Button2.TabIndex = 5
        Me.Button2.Text = "E&xit"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'radGlazed
        '
        Me.radGlazed.AutoSize = True
        Me.radGlazed.Location = New System.Drawing.Point(7, 20)
        Me.radGlazed.Name = "radGlazed"
        Me.radGlazed.Size = New System.Drawing.Size(88, 17)
        Me.radGlazed.TabIndex = 0
        Me.radGlazed.TabStop = True
        Me.radGlazed.Text = "&Glazed ($.65)"
        Me.radGlazed.UseVisualStyleBackColor = True
        '
        'radSugar
        '
        Me.radSugar.AutoSize = True
        Me.radSugar.Location = New System.Drawing.Point(7, 44)
        Me.radSugar.Name = "radSugar"
        Me.radSugar.Size = New System.Drawing.Size(83, 17)
        Me.radSugar.TabIndex = 1
        Me.radSugar.TabStop = True
        Me.radSugar.Text = "&Sugar ($.65)"
        Me.radSugar.UseVisualStyleBackColor = True
        '
        'radChocolate
        '
        Me.radChocolate.AutoSize = True
        Me.radChocolate.Location = New System.Drawing.Point(7, 69)
        Me.radChocolate.Name = "radChocolate"
        Me.radChocolate.Size = New System.Drawing.Size(103, 17)
        Me.radChocolate.TabIndex = 2
        Me.radChocolate.TabStop = True
        Me.radChocolate.Text = "C&hocolate ($.85)"
        Me.radChocolate.UseVisualStyleBackColor = True
        '
        'radFilled
        '
        Me.radFilled.AutoSize = True
        Me.radFilled.Location = New System.Drawing.Point(7, 91)
        Me.radFilled.Name = "radFilled"
        Me.radFilled.Size = New System.Drawing.Size(85, 17)
        Me.radFilled.TabIndex = 3
        Me.radFilled.TabStop = True
        Me.radFilled.Text = "&Filled ($1.00)"
        Me.radFilled.UseVisualStyleBackColor = True
        '
        'radNone
        '
        Me.radNone.AutoSize = True
        Me.radNone.Location = New System.Drawing.Point(7, 20)
        Me.radNone.Name = "radNone"
        Me.radNone.Size = New System.Drawing.Size(51, 17)
        Me.radNone.TabIndex = 0
        Me.radNone.TabStop = True
        Me.radNone.Text = "&None"
        Me.radNone.UseVisualStyleBackColor = True
        '
        'radRegular
        '
        Me.radRegular.AutoSize = True
        Me.radRegular.Location = New System.Drawing.Point(7, 44)
        Me.radRegular.Name = "radRegular"
        Me.radRegular.Size = New System.Drawing.Size(98, 17)
        Me.radRegular.TabIndex = 1
        Me.radRegular.TabStop = True
        Me.radRegular.Text = "&Regular ($1.80)"
        Me.radRegular.UseVisualStyleBackColor = True
        '
        'radCapp
        '
        Me.radCapp.AutoSize = True
        Me.radCapp.Location = New System.Drawing.Point(7, 67)
        Me.radCapp.Name = "radCapp"
        Me.radCapp.Size = New System.Drawing.Size(118, 17)
        Me.radCapp.TabIndex = 2
        Me.radCapp.TabStop = True
        Me.radCapp.Text = "Ca&ppuccino ($2.50)"
        Me.radCapp.UseVisualStyleBackColor = True
        '
        'lblSubtotal
        '
        Me.lblSubtotal.AutoSize = True
        Me.lblSubtotal.Location = New System.Drawing.Point(7, 20)
        Me.lblSubtotal.Name = "lblSubtotal"
        Me.lblSubtotal.Size = New System.Drawing.Size(49, 13)
        Me.lblSubtotal.TabIndex = 0
        Me.lblSubtotal.Text = "Subtotal:"
        '
        'lblSalesTax
        '
        Me.lblSalesTax.AutoSize = True
        Me.lblSalesTax.Location = New System.Drawing.Point(3, 53)
        Me.lblSalesTax.Name = "lblSalesTax"
        Me.lblSalesTax.Size = New System.Drawing.Size(53, 13)
        Me.lblSalesTax.TabIndex = 1
        Me.lblSalesTax.Text = "Sales tax:"
        '
        'lblTotalDue
        '
        Me.lblTotalDue.AutoSize = True
        Me.lblTotalDue.Location = New System.Drawing.Point(3, 81)
        Me.lblTotalDue.Name = "lblTotalDue"
        Me.lblTotalDue.Size = New System.Drawing.Size(55, 13)
        Me.lblTotalDue.TabIndex = 2
        Me.lblTotalDue.Text = "Total due:"
        '
        'txtSubtotal
        '
        Me.txtSubtotal.Location = New System.Drawing.Point(68, 12)
        Me.txtSubtotal.Name = "txtSubtotal"
        Me.txtSubtotal.Size = New System.Drawing.Size(90, 20)
        Me.txtSubtotal.TabIndex = 3
        '
        'txtTax
        '
        Me.txtTax.Location = New System.Drawing.Point(68, 44)
        Me.txtTax.Name = "txtTax"
        Me.txtTax.Size = New System.Drawing.Size(90, 20)
        Me.txtTax.TabIndex = 4
        '
        'txtTotalDue
        '
        Me.txtTotalDue.Location = New System.Drawing.Point(68, 78)
        Me.txtTotalDue.Name = "txtTotalDue"
        Me.txtTotalDue.Size = New System.Drawing.Size(90, 20)
        Me.txtTotalDue.TabIndex = 5
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(454, 326)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.grbCoffee)
        Me.Controls.Add(Me.grbDoughnut)
        Me.Name = "frmMain"
        Me.Text = "Sweet Life"
        Me.grbDoughnut.ResumeLayout(False)
        Me.grbDoughnut.PerformLayout()
        Me.grbCoffee.ResumeLayout(False)
        Me.grbCoffee.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents grbDoughnut As GroupBox
    Friend WithEvents radFilled As RadioButton
    Friend WithEvents radChocolate As RadioButton
    Friend WithEvents radSugar As RadioButton
    Friend WithEvents radGlazed As RadioButton
    Friend WithEvents grbCoffee As GroupBox
    Friend WithEvents radCapp As RadioButton
    Friend WithEvents radRegular As RadioButton
    Friend WithEvents radNone As RadioButton
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents txtTotalDue As TextBox
    Friend WithEvents txtTax As TextBox
    Friend WithEvents txtSubtotal As TextBox
    Friend WithEvents lblTotalDue As Label
    Friend WithEvents lblSalesTax As Label
    Friend WithEvents lblSubtotal As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
End Class
