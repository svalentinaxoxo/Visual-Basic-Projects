﻿' Name:         Sweet Life Solution
' Purpose:      Calculates and Displays a customer's Subtotal, sales tax, and Total due 
' Programmer:   <Shelby Laquitara> on <04/07/2016>

Public Class frmMain
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim subTotal As Double = 0
        Dim salesTax As Double
        Dim totalDue As Double

        If radGlazed.Checked Then
            subTotal += 0.65
        ElseIf radSugar.Checked Then
            subTotal += 0.65
        ElseIf radChocolate.Checked Then
            subTotal += 0.85
        ElseIf radCapp.Checked Then
            subTotal += 1.0
        End If

        If radNone.Checked Then
            subTotal += 0
        ElseIf radRegular.Checked Then
            subTotal += 1.8
        ElseIf radCapp.Checked Then
            subTotal += 2.5
        End If

        salesTax = subTotal * 0.03
        totalDue = subTotal + salesTax

        txtSubtotal.Text = subTotal.ToString("C2")
        txtTax.Text = salesTax.ToString("C2")
        txtTotalDue.Text = totalDue.ToString("C2")
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()
    End Sub
End Class
