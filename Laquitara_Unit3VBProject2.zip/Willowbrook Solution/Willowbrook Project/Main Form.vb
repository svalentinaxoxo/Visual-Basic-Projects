﻿' Name: Willowbrook Solution
' Purpose: the application calculates the monthly dues by adding the
' basic fee + any additional fees.
' Programmer: <Shelby Laquitara> on <04/3/2016>

Public Class frmMain
    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        'declaring the variables
        Dim MonthlyDues As Double
        Dim additional As Double
        Dim basicFee As Double

        basicFee = Val(txtBasic.Text)

        'initalize additional to 0 
        additional = 0

        'calculate charges
        If chkGolf.Checked Then
            additional = additional + 25
        End If

        If chkTennis.Checked Then
            additional = additional + 30
        End If

        If chkRacquetball.Checked Then
            additional = additional + 20
        End If

        'calculate monthly dues 
        MonthlyDues = basicFee + additional

        'display the addiontal dues in textbox
        txtAdditional.Text = additional.ToString()

        'display the total monthly dues 
        rtbMonthlyDues.Text = MonthlyDues.ToString()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
