﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtBasic = New System.Windows.Forms.TextBox()
        Me.txtAdditional = New System.Windows.Forms.TextBox()
        Me.rtbMonthlyDues = New System.Windows.Forms.RichTextBox()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.chkGolf = New System.Windows.Forms.CheckBox()
        Me.chkTennis = New System.Windows.Forms.CheckBox()
        Me.chkRacquetball = New System.Windows.Forms.CheckBox()
        Me.lblFee = New System.Windows.Forms.Label()
        Me.lblAdditional = New System.Windows.Forms.Label()
        Me.lblMonthlyDues = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'txtBasic
        '
        Me.txtBasic.Location = New System.Drawing.Point(22, 40)
        Me.txtBasic.Name = "txtBasic"
        Me.txtBasic.Size = New System.Drawing.Size(100, 20)
        Me.txtBasic.TabIndex = 0
        '
        'txtAdditional
        '
        Me.txtAdditional.Location = New System.Drawing.Point(22, 104)
        Me.txtAdditional.Name = "txtAdditional"
        Me.txtAdditional.ReadOnly = True
        Me.txtAdditional.Size = New System.Drawing.Size(100, 20)
        Me.txtAdditional.TabIndex = 1
        '
        'rtbMonthlyDues
        '
        Me.rtbMonthlyDues.Location = New System.Drawing.Point(22, 160)
        Me.rtbMonthlyDues.Name = "rtbMonthlyDues"
        Me.rtbMonthlyDues.ReadOnly = True
        Me.rtbMonthlyDues.Size = New System.Drawing.Size(100, 70)
        Me.rtbMonthlyDues.TabIndex = 3
        Me.rtbMonthlyDues.Text = ""
        '
        'btnCalculate
        '
        Me.btnCalculate.Location = New System.Drawing.Point(169, 206)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(75, 23)
        Me.btnCalculate.TabIndex = 4
        Me.btnCalculate.Text = "&Calculate"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(259, 206)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 5
        Me.btnExit.Text = "E&xit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'chkGolf
        '
        Me.chkGolf.AutoSize = True
        Me.chkGolf.Location = New System.Drawing.Point(214, 43)
        Me.chkGolf.Name = "chkGolf"
        Me.chkGolf.Size = New System.Drawing.Size(45, 17)
        Me.chkGolf.TabIndex = 6
        Me.chkGolf.Text = "&Golf"
        Me.chkGolf.UseVisualStyleBackColor = True
        '
        'chkTennis
        '
        Me.chkTennis.AutoSize = True
        Me.chkTennis.Location = New System.Drawing.Point(214, 82)
        Me.chkTennis.Name = "chkTennis"
        Me.chkTennis.Size = New System.Drawing.Size(58, 17)
        Me.chkTennis.TabIndex = 7
        Me.chkTennis.Text = "&Tennis"
        Me.chkTennis.UseVisualStyleBackColor = True
        '
        'chkRacquetball
        '
        Me.chkRacquetball.AutoSize = True
        Me.chkRacquetball.Location = New System.Drawing.Point(214, 124)
        Me.chkRacquetball.Name = "chkRacquetball"
        Me.chkRacquetball.Size = New System.Drawing.Size(83, 17)
        Me.chkRacquetball.TabIndex = 8
        Me.chkRacquetball.Text = "&Racquetball"
        Me.chkRacquetball.UseVisualStyleBackColor = True
        '
        'lblFee
        '
        Me.lblFee.AutoSize = True
        Me.lblFee.Location = New System.Drawing.Point(22, 22)
        Me.lblFee.Name = "lblFee"
        Me.lblFee.Size = New System.Drawing.Size(54, 13)
        Me.lblFee.TabIndex = 9
        Me.lblFee.Text = "&Basic fee:"
        '
        'lblAdditional
        '
        Me.lblAdditional.AutoSize = True
        Me.lblAdditional.Location = New System.Drawing.Point(22, 85)
        Me.lblAdditional.Name = "lblAdditional"
        Me.lblAdditional.Size = New System.Drawing.Size(56, 13)
        Me.lblAdditional.TabIndex = 10
        Me.lblAdditional.Text = "Additional:"
        '
        'lblMonthlyDues
        '
        Me.lblMonthlyDues.AutoSize = True
        Me.lblMonthlyDues.Location = New System.Drawing.Point(22, 144)
        Me.lblMonthlyDues.Name = "lblMonthlyDues"
        Me.lblMonthlyDues.Size = New System.Drawing.Size(73, 13)
        Me.lblMonthlyDues.TabIndex = 11
        Me.lblMonthlyDues.Text = "Monthly dues:"
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(372, 261)
        Me.Controls.Add(Me.lblMonthlyDues)
        Me.Controls.Add(Me.lblAdditional)
        Me.Controls.Add(Me.lblFee)
        Me.Controls.Add(Me.chkRacquetball)
        Me.Controls.Add(Me.chkTennis)
        Me.Controls.Add(Me.chkGolf)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.rtbMonthlyDues)
        Me.Controls.Add(Me.txtAdditional)
        Me.Controls.Add(Me.txtBasic)
        Me.Name = "frmMain"
        Me.Text = "Willowbrook Health Club"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtBasic As TextBox
    Friend WithEvents txtAdditional As TextBox
    Friend WithEvents rtbMonthlyDues As RichTextBox
    Friend WithEvents btnCalculate As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents chkGolf As CheckBox
    Friend WithEvents chkTennis As CheckBox
    Friend WithEvents chkRacquetball As CheckBox
    Friend WithEvents lblFee As Label
    Friend WithEvents lblAdditional As Label
    Friend WithEvents lblMonthlyDues As Label
End Class
