﻿' Name: Modified Guessing Game Solution
' Purpose: the application generates a random number then
' allows user to guess the number within 5 tries.
' Programmer: <Shelby Laquitara> on <04/3/2016>

Public Class frmMain
    Public Counter As Integer

    Private Sub btnExit_Click(sender As Object,
e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
        'declaring variables
        Dim randGen As New Random
        Dim intNum As Integer
        Dim userGuess As Integer

        'assign random integer from 1 through 25
        intNum = randGen.Next(1, 25)

        userGuess = Val(txtGuess.Text)
        'only allow user 5 guesses before showing the answer!
        If Counter >= 5 Then
            MessageBox.Show(intNum.ToString)
        ElseIf userGuess > intNum Then
            MessageBox.Show("Guess Lower.", "Guessing Game",
                 MessageBoxButtons.OK, MessageBoxIcon.Information)
            Counter += 1
        ElseIf userGuess < intNum Then
            MessageBox.Show("Guess Higher.", "Guessing Game",
                 MessageBoxButtons.OK, MessageBoxIcon.Information)
            Counter += 1
        Else
            MessageBox.Show("You are correct. The random integer is " + intNum.ToString(), "Guessing Game",
                 MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If
    End Sub

    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles Me.Load
        Counter = 0
    End Sub
End Class
