﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblID = New System.Windows.Forms.Label()
        Me.lblNumberSold = New System.Windows.Forms.Label()
        Me.txtID = New System.Windows.Forms.TextBox()
        Me.txtNumberSold = New System.Windows.Forms.TextBox()
        Me.btnCalc = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.lblFullTime = New System.Windows.Forms.Label()
        Me.lblPart = New System.Windows.Forms.Label()
        Me.lblNewCar = New System.Windows.Forms.Label()
        Me.lblUsedCar = New System.Windows.Forms.Label()
        Me.txtFull = New System.Windows.Forms.TextBox()
        Me.txtPart = New System.Windows.Forms.TextBox()
        Me.txtNew = New System.Windows.Forms.TextBox()
        Me.txtUsed = New System.Windows.Forms.TextBox()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblID
        '
        Me.lblID.AutoSize = True
        Me.lblID.Location = New System.Drawing.Point(164, 60)
        Me.lblID.Name = "lblID"
        Me.lblID.Size = New System.Drawing.Size(21, 13)
        Me.lblID.TabIndex = 0
        Me.lblID.Text = "&ID:"
        '
        'lblNumberSold
        '
        Me.lblNumberSold.AutoSize = True
        Me.lblNumberSold.Location = New System.Drawing.Point(318, 59)
        Me.lblNumberSold.Name = "lblNumberSold"
        Me.lblNumberSold.Size = New System.Drawing.Size(69, 13)
        Me.lblNumberSold.TabIndex = 1
        Me.lblNumberSold.Text = "&Number sold:"
        '
        'txtID
        '
        Me.txtID.Location = New System.Drawing.Point(167, 77)
        Me.txtID.Name = "txtID"
        Me.txtID.Size = New System.Drawing.Size(100, 20)
        Me.txtID.TabIndex = 2
        '
        'txtNumberSold
        '
        Me.txtNumberSold.Location = New System.Drawing.Point(321, 76)
        Me.txtNumberSold.Name = "txtNumberSold"
        Me.txtNumberSold.Size = New System.Drawing.Size(100, 20)
        Me.txtNumberSold.TabIndex = 3
        '
        'btnCalc
        '
        Me.btnCalc.Location = New System.Drawing.Point(167, 115)
        Me.btnCalc.Name = "btnCalc"
        Me.btnCalc.Size = New System.Drawing.Size(75, 23)
        Me.btnCalc.TabIndex = 4
        Me.btnCalc.Text = "&Calculate"
        Me.btnCalc.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(321, 115)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 5
        Me.btnExit.Text = "E&xit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.Huntington_Project.My.Resources.Resources.Car
        Me.PictureBox1.Location = New System.Drawing.Point(30, 41)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(100, 104)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 6
        Me.PictureBox1.TabStop = False
        '
        'lblFullTime
        '
        Me.lblFullTime.AutoSize = True
        Me.lblFullTime.Location = New System.Drawing.Point(145, 178)
        Me.lblFullTime.Name = "lblFullTime"
        Me.lblFullTime.Size = New System.Drawing.Size(158, 13)
        Me.lblFullTime.TabIndex = 7
        Me.lblFullTime.Text = "Cars sold by full-time employees:"
        '
        'lblPart
        '
        Me.lblPart.AutoSize = True
        Me.lblPart.Location = New System.Drawing.Point(147, 211)
        Me.lblPart.Name = "lblPart"
        Me.lblPart.Size = New System.Drawing.Size(163, 13)
        Me.lblPart.TabIndex = 8
        Me.lblPart.Text = "Cars sold by part-time employees:"
        '
        'lblNewCar
        '
        Me.lblNewCar.AutoSize = True
        Me.lblNewCar.Location = New System.Drawing.Point(147, 240)
        Me.lblNewCar.Name = "lblNewCar"
        Me.lblNewCar.Size = New System.Drawing.Size(161, 13)
        Me.lblNewCar.TabIndex = 9
        Me.lblNewCar.Text = "Cars sold by new car employees:"
        '
        'lblUsedCar
        '
        Me.lblUsedCar.AutoSize = True
        Me.lblUsedCar.Location = New System.Drawing.Point(146, 272)
        Me.lblUsedCar.Name = "lblUsedCar"
        Me.lblUsedCar.Size = New System.Drawing.Size(164, 13)
        Me.lblUsedCar.TabIndex = 10
        Me.lblUsedCar.Text = "Cars sold by used car employees:"
        '
        'txtFull
        '
        Me.txtFull.Location = New System.Drawing.Point(321, 178)
        Me.txtFull.Name = "txtFull"
        Me.txtFull.Size = New System.Drawing.Size(100, 20)
        Me.txtFull.TabIndex = 11
        '
        'txtPart
        '
        Me.txtPart.Location = New System.Drawing.Point(321, 208)
        Me.txtPart.Name = "txtPart"
        Me.txtPart.Size = New System.Drawing.Size(100, 20)
        Me.txtPart.TabIndex = 12
        '
        'txtNew
        '
        Me.txtNew.Location = New System.Drawing.Point(321, 237)
        Me.txtNew.Name = "txtNew"
        Me.txtNew.Size = New System.Drawing.Size(100, 20)
        Me.txtNew.TabIndex = 13
        '
        'txtUsed
        '
        Me.txtUsed.Location = New System.Drawing.Point(321, 269)
        Me.txtUsed.Name = "txtUsed"
        Me.txtUsed.Size = New System.Drawing.Size(100, 20)
        Me.txtUsed.TabIndex = 14
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(438, 321)
        Me.Controls.Add(Me.txtUsed)
        Me.Controls.Add(Me.txtNew)
        Me.Controls.Add(Me.txtPart)
        Me.Controls.Add(Me.txtFull)
        Me.Controls.Add(Me.lblUsedCar)
        Me.Controls.Add(Me.lblNewCar)
        Me.Controls.Add(Me.lblPart)
        Me.Controls.Add(Me.lblFullTime)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnCalc)
        Me.Controls.Add(Me.txtNumberSold)
        Me.Controls.Add(Me.txtID)
        Me.Controls.Add(Me.lblNumberSold)
        Me.Controls.Add(Me.lblID)
        Me.Name = "frmMain"
        Me.Text = "Huntington Motors"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblID As Label
    Friend WithEvents lblNumberSold As Label
    Friend WithEvents txtID As TextBox
    Friend WithEvents txtNumberSold As TextBox
    Friend WithEvents btnCalc As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents lblFullTime As Label
    Friend WithEvents lblPart As Label
    Friend WithEvents lblNewCar As Label
    Friend WithEvents lblUsedCar As Label
    Friend WithEvents txtFull As TextBox
    Friend WithEvents txtPart As TextBox
    Friend WithEvents txtNew As TextBox
    Friend WithEvents txtUsed As TextBox
End Class
