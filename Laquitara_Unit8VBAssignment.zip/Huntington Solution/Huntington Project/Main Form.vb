﻿Public Class frmMain

    Private NewCarEmp As Integer = 0
    Private UsedCarEmp As Integer = 0
    Private FullTimeEmp As Integer = 0
    Private PartTimeEmp As Integer = 0

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click

        Dim ID As String = txtID.Text

        If Not ID Like "[1-2][A-Z][A-Z][FP]" Then
            MessageBox.Show("Error", "Huntington", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Else
            If ID Like "1*" Then
                NewCarEmp += Convert.ToInt32(txtNumberSold.Text)
            End If
            If ID Like "2*" Then
                UsedCarEmp += Convert.ToInt32(txtNumberSold.Text)
            End If
            If ID Like "*F" Then
                FullTimeEmp += Convert.ToInt32(txtNumberSold.Text)
            End If
            If ID Like "*P" Then
                PartTimeEmp += Convert.ToInt32(txtNumberSold.Text)
            End If

            txtFull.Text = FullTimeEmp.ToString()
            txtPart.Text = PartTimeEmp.ToString()
            txtNew.Text = NewCarEmp.ToString()
            txtUsed.Text = UsedCarEmp.ToString()
        End If
    End Sub
End Class
