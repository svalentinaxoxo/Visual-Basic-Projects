' Name:         Jacobson Project
' Purpose:      Display a new password
' Programmer:   <your name> on <current date>

Option Explicit On
Option Strict On
Option Infer Off

Public Class frmMain

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub txtOrigPassword_TextChanged(sender As Object, e As EventArgs) Handles txtOrigPassword.TextChanged
        lblNewPassword.Text = String.Empty
    End Sub

    Private Sub btnDisplay_Click(sender As Object, e As EventArgs) Handles btnDisplay.Click

        Dim NewPass As String = lblNewPassword.Text
        Dim OrgPass As String = txtOrigPassword.Text

        If OrgPass.Length < 5 Or OrgPass.Length > 7 Then
            MessageBox.Show("Please enter a password between 5 and 7 characters!", "Jacobson",
                            MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Else
            NewPass = System.Text.RegularExpressions.Regex.Replace(OrgPass, "[AEIOU]", "X")
            NewPass = System.Text.RegularExpressions.Regex.Replace(NewPass, "[0-9]", "Z")
            NewPass = StrReverse(NewPass)
        End If
        lblNewPassword.Text = NewPass.ToString()
    End Sub
End Class
