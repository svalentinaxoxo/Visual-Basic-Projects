' Name:         Conversion Functions Project
' Purpose:      Demonstrates the use of the Visual Basic conversion functions
' Programmer:   <Shelby Laquitara> on <03/27/2016>

Option Explicit On
Option Strict On
Option Infer Off

Public Class frmMain

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        ' calculates the total price

        Dim decPrice As Decimal
        Dim decTotalPrice As Decimal
        Dim intNumberOfItems As Integer

        ' convert input to numbers
        Decimal.TryParse(txtPrice.Text, decPrice)
        Integer.TryParse(txtPurchased.Text, intNumberOfItems)

        ' calculate and display the total price
        decPrice = CDec(txtPrice.Text)
        intNumberOfItems = CInt(txtPurchased.Text)
        decTotalPrice = decPrice * intNumberOfItems
        txtTotalPrice.Text = decTotalPrice.ToString("C2")
    End Sub
End Class
