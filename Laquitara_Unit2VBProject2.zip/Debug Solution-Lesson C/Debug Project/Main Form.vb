' Name:         Debug Project
' Purpose:      Calculates the average of three test scores
' Programmer:   <Shelby> on <03/27/2016>

Option Explicit On
Option Strict On
Option Infer Off

Public Class frmMain

    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        ' calculates the average of three test scores

        Dim decTest1 As Integer
        Dim decTest2 As Integer
        Dim decTest3 As Integer
        Dim decTotal As Integer
        Dim decAverage As Integer

        'Calculate total number entered
        Integer.TryParse(txtTest1.Text, decTest1)
        Integer.TryParse(txtTest2.Text, decTest2)
        Integer.TryParse(txtTest3.Text, decTest3)
        decTotal = decTest1 + decTest2 + decTest3

        ' calculate and display the average
        decAverage = decTotal \ 3
        txtAverage.Text = decAverage.ToString("N")
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
