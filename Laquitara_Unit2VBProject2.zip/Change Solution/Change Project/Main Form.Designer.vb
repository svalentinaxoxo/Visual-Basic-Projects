﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtOwed = New System.Windows.Forms.TextBox()
        Me.txtPaid = New System.Windows.Forms.TextBox()
        Me.txtChangeDue = New System.Windows.Forms.TextBox()
        Me.txtDollars = New System.Windows.Forms.TextBox()
        Me.txtQuarters = New System.Windows.Forms.TextBox()
        Me.txtDimes = New System.Windows.Forms.TextBox()
        Me.txtNickels = New System.Windows.Forms.TextBox()
        Me.txtPennies = New System.Windows.Forms.TextBox()
        Me.lblOwed = New System.Windows.Forms.Label()
        Me.lblPaid = New System.Windows.Forms.Label()
        Me.lblChangeDue = New System.Windows.Forms.Label()
        Me.lblDollars = New System.Windows.Forms.Label()
        Me.lblQuarters = New System.Windows.Forms.Label()
        Me.lblDimes = New System.Windows.Forms.Label()
        Me.lblNickels = New System.Windows.Forms.Label()
        Me.lblPennies = New System.Windows.Forms.Label()
        Me.btnCalcChange = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'txtOwed
        '
        Me.txtOwed.Location = New System.Drawing.Point(97, 33)
        Me.txtOwed.Name = "txtOwed"
        Me.txtOwed.Size = New System.Drawing.Size(100, 20)
        Me.txtOwed.TabIndex = 0
        '
        'txtPaid
        '
        Me.txtPaid.Location = New System.Drawing.Point(97, 75)
        Me.txtPaid.Name = "txtPaid"
        Me.txtPaid.Size = New System.Drawing.Size(100, 20)
        Me.txtPaid.TabIndex = 1
        '
        'txtChangeDue
        '
        Me.txtChangeDue.Location = New System.Drawing.Point(97, 116)
        Me.txtChangeDue.Name = "txtChangeDue"
        Me.txtChangeDue.ReadOnly = True
        Me.txtChangeDue.Size = New System.Drawing.Size(100, 20)
        Me.txtChangeDue.TabIndex = 2
        '
        'txtDollars
        '
        Me.txtDollars.Location = New System.Drawing.Point(12, 213)
        Me.txtDollars.Name = "txtDollars"
        Me.txtDollars.ReadOnly = True
        Me.txtDollars.Size = New System.Drawing.Size(69, 20)
        Me.txtDollars.TabIndex = 3
        '
        'txtQuarters
        '
        Me.txtQuarters.Location = New System.Drawing.Point(97, 213)
        Me.txtQuarters.Name = "txtQuarters"
        Me.txtQuarters.ReadOnly = True
        Me.txtQuarters.Size = New System.Drawing.Size(75, 20)
        Me.txtQuarters.TabIndex = 4
        '
        'txtDimes
        '
        Me.txtDimes.Location = New System.Drawing.Point(189, 213)
        Me.txtDimes.Name = "txtDimes"
        Me.txtDimes.ReadOnly = True
        Me.txtDimes.Size = New System.Drawing.Size(68, 20)
        Me.txtDimes.TabIndex = 5
        '
        'txtNickels
        '
        Me.txtNickels.Location = New System.Drawing.Point(281, 213)
        Me.txtNickels.Name = "txtNickels"
        Me.txtNickels.ReadOnly = True
        Me.txtNickels.Size = New System.Drawing.Size(71, 20)
        Me.txtNickels.TabIndex = 6
        '
        'txtPennies
        '
        Me.txtPennies.Location = New System.Drawing.Point(379, 213)
        Me.txtPennies.Name = "txtPennies"
        Me.txtPennies.ReadOnly = True
        Me.txtPennies.Size = New System.Drawing.Size(70, 20)
        Me.txtPennies.TabIndex = 7
        '
        'lblOwed
        '
        Me.lblOwed.AutoSize = True
        Me.lblOwed.Location = New System.Drawing.Point(12, 33)
        Me.lblOwed.Name = "lblOwed"
        Me.lblOwed.Size = New System.Drawing.Size(75, 13)
        Me.lblOwed.TabIndex = 8
        Me.lblOwed.Text = "Amount &owed:"
        '
        'lblPaid
        '
        Me.lblPaid.AutoSize = True
        Me.lblPaid.Location = New System.Drawing.Point(12, 75)
        Me.lblPaid.Name = "lblPaid"
        Me.lblPaid.Size = New System.Drawing.Size(69, 13)
        Me.lblPaid.TabIndex = 9
        Me.lblPaid.Text = "Amount &paid:"
        '
        'lblChangeDue
        '
        Me.lblChangeDue.AutoSize = True
        Me.lblChangeDue.Location = New System.Drawing.Point(12, 116)
        Me.lblChangeDue.Name = "lblChangeDue"
        Me.lblChangeDue.Size = New System.Drawing.Size(68, 13)
        Me.lblChangeDue.TabIndex = 10
        Me.lblChangeDue.Text = "Change due:"
        '
        'lblDollars
        '
        Me.lblDollars.AutoSize = True
        Me.lblDollars.Location = New System.Drawing.Point(12, 194)
        Me.lblDollars.Name = "lblDollars"
        Me.lblDollars.Size = New System.Drawing.Size(42, 13)
        Me.lblDollars.TabIndex = 11
        Me.lblDollars.Text = "Dollars:"
        '
        'lblQuarters
        '
        Me.lblQuarters.AutoSize = True
        Me.lblQuarters.Location = New System.Drawing.Point(97, 193)
        Me.lblQuarters.Name = "lblQuarters"
        Me.lblQuarters.Size = New System.Drawing.Size(50, 13)
        Me.lblQuarters.TabIndex = 12
        Me.lblQuarters.Text = "Quarters:"
        '
        'lblDimes
        '
        Me.lblDimes.AutoSize = True
        Me.lblDimes.Location = New System.Drawing.Point(189, 192)
        Me.lblDimes.Name = "lblDimes"
        Me.lblDimes.Size = New System.Drawing.Size(39, 13)
        Me.lblDimes.TabIndex = 13
        Me.lblDimes.Text = "Dimes:"
        '
        'lblNickels
        '
        Me.lblNickels.AutoSize = True
        Me.lblNickels.Location = New System.Drawing.Point(281, 192)
        Me.lblNickels.Name = "lblNickels"
        Me.lblNickels.Size = New System.Drawing.Size(45, 13)
        Me.lblNickels.TabIndex = 14
        Me.lblNickels.Text = "Nickels:"
        '
        'lblPennies
        '
        Me.lblPennies.AutoSize = True
        Me.lblPennies.Location = New System.Drawing.Point(379, 194)
        Me.lblPennies.Name = "lblPennies"
        Me.lblPennies.Size = New System.Drawing.Size(48, 13)
        Me.lblPennies.TabIndex = 15
        Me.lblPennies.Text = "Pennies:"
        '
        'btnCalcChange
        '
        Me.btnCalcChange.Location = New System.Drawing.Point(240, 32)
        Me.btnCalcChange.Name = "btnCalcChange"
        Me.btnCalcChange.Size = New System.Drawing.Size(111, 21)
        Me.btnCalcChange.TabIndex = 16
        Me.btnCalcChange.Text = "&Calculate Change"
        Me.btnCalcChange.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(240, 72)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(111, 23)
        Me.btnClear.TabIndex = 17
        Me.btnClear.Text = "Clea&r Screen"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(240, 116)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(112, 23)
        Me.btnExit.TabIndex = 18
        Me.btnExit.Text = "E&xit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AcceptButton = Me.btnCalcChange
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(507, 261)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnCalcChange)
        Me.Controls.Add(Me.lblPennies)
        Me.Controls.Add(Me.lblNickels)
        Me.Controls.Add(Me.lblDimes)
        Me.Controls.Add(Me.lblQuarters)
        Me.Controls.Add(Me.lblDollars)
        Me.Controls.Add(Me.lblChangeDue)
        Me.Controls.Add(Me.lblPaid)
        Me.Controls.Add(Me.lblOwed)
        Me.Controls.Add(Me.txtPennies)
        Me.Controls.Add(Me.txtNickels)
        Me.Controls.Add(Me.txtDimes)
        Me.Controls.Add(Me.txtQuarters)
        Me.Controls.Add(Me.txtDollars)
        Me.Controls.Add(Me.txtChangeDue)
        Me.Controls.Add(Me.txtPaid)
        Me.Controls.Add(Me.txtOwed)
        Me.Name = "Form1"
        Me.Text = "Change Calculator"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtOwed As TextBox
    Friend WithEvents txtPaid As TextBox
    Friend WithEvents txtChangeDue As TextBox
    Friend WithEvents txtDollars As TextBox
    Friend WithEvents txtQuarters As TextBox
    Friend WithEvents txtDimes As TextBox
    Friend WithEvents txtNickels As TextBox
    Friend WithEvents txtPennies As TextBox
    Friend WithEvents lblOwed As Label
    Friend WithEvents lblPaid As Label
    Friend WithEvents lblChangeDue As Label
    Friend WithEvents lblDollars As Label
    Friend WithEvents lblQuarters As Label
    Friend WithEvents lblDimes As Label
    Friend WithEvents lblNickels As Label
    Friend WithEvents lblPennies As Label
    Friend WithEvents btnCalcChange As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents btnExit As Button
End Class
