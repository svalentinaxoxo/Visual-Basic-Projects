﻿Public Class Form1

    Private decTotal As Decimal

    Private Sub btnCalcChange_Click(sender As Object, e As EventArgs) Handles btnCalcChange.Click

        Dim dollars As Decimal
        Dim quarters As Decimal
        Dim dimes As Decimal
        Dim nickels As Decimal
        Dim pennies As Decimal
        Dim value As Decimal
        Dim decOwed As Decimal
        Dim decPaid As Decimal
        Dim decChangeDue As Decimal


        'total the amounts
        Decimal.TryParse(txtOwed.Text, decOwed)
        Decimal.TryParse(txtPaid.Text, decPaid)
        Decimal.TryParse(txtChangeDue.Text, decChangeDue)
        txtChangeDue.Text = txtPaid.Text - txtOwed.Text

        value = txtChangeDue.Text
        dollars = value \ 1
        txtDollars.Text = dollars.ToString
        value = value - dollars * 1

        quarters = value \ 4
        txtQuarters.Text = quarters.ToString
        value = value - quarters * 4

        dimes = value \ 10
        txtDimes.Text = dimes.ToString
        value = value - dimes * 10

        nickels = value \ 20
        txtNickels.Text = nickels.ToString
        value = value - nickels * 20

        pennies = value \ 100
        txtPennies.Text = value.ToString
        value = value - pennies * 100

    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        txtOwed.Text = ""
        txtPaid.Text = ""
        txtDollars.Text = ""
        txtQuarters.Text = ""
        txtDimes.Text = ""
        txtNickels.Text = ""
        txtPennies.Text = ""
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub txtOwed_TextChanged(sender As Object, e As EventArgs) Handles txtOwed.TextChanged
        txtChangeDue.Text = String.Empty
        txtDollars.Text = String.Empty
        txtQuarters.Text = String.Empty
        txtDimes.Text = String.Empty
        txtNickels.Text = String.Empty
        txtPennies.Text = String.Empty
    End Sub

    Private Sub txtPaid_TextChanged(sender As Object, e As EventArgs) Handles txtPaid.TextChanged
        txtChangeDue.Text = String.Empty
        txtDollars.Text = String.Empty
        txtQuarters.Text = String.Empty
        txtDimes.Text = String.Empty
        txtNickels.Text = String.Empty
        txtPennies.Text = String.Empty
    End Sub
End Class
