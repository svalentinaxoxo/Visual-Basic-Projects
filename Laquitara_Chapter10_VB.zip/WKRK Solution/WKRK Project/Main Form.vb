﻿' Name:         WKRK Solution
' Purpose:      Allows the manager to enter a callers choice and saves it in a sequential access file,
'               and displays the number of votes for each commerical. 
' Programmer:   <Shelby Laquitara> on <04/21/2016>

Public Class frmMain

    Private Sub frmMain_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        lstCommercial.Items.Add("Budwiser")
        lstCommercial.Items.Add("FedEx")
        lstCommercial.Items.Add("ETrade")
        lstCommercial.Items.Add("Pepsi")
    End Sub

    Private Sub btnSave_Click(sender As System.Object, e As System.EventArgs) Handles btnSave.Click

        Dim outfile As IO.StreamWriter
        outfile = IO.File.AppendText("votes.txt")
        outfile.WriteLine(lstCommercial.SelectedItem)
        outfile.Close()
    End Sub

    Private Sub btnDisplay_Click(sender As System.Object, e As System.EventArgs) Handles btnDisplay.Click

        Dim inFile As IO.StreamReader
        Dim fileName As String
        Dim bud As Integer
        Dim fedEx As Integer
        Dim eTrade As Integer
        Dim pepsi As Integer

        If IO.File.Exists("votes.txt") Then
            inFile = IO.File.OpenText("votes.txt")

            Do Until inFile.Peek = -1
                fileName = inFile.ReadLine
                If fileName = "Budwiser" Then
                    bud += 1
                ElseIf fileName = "FedEx" Then
                    fedEx += 1
                ElseIf fileName = "ETrade" Then
                    eTrade += 1
                ElseIf fileName = "Pepsi" Then
                    pepsi += 1
                End If
            Loop
            inFile.Close()
            lstCommercial.SelectedIndex = 0
            txtBud.Text = bud.ToString
            txtFedEx.Text = fedEx.ToString
            txtETrade.Text = eTrade.ToString
            txtPepsi.Text = pepsi.ToString

        Else
            MessageBox.Show("You did not choose from the listbox", "WKRK", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If
    End Sub

    Private Sub btnExit_Click(sender As System.Object, e As System.EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub
End Class
