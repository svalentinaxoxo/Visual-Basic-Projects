﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lstCommercial = New System.Windows.Forms.ListBox()
        Me.txtBud = New System.Windows.Forms.TextBox()
        Me.txtFedEx = New System.Windows.Forms.TextBox()
        Me.txtETrade = New System.Windows.Forms.TextBox()
        Me.txtPepsi = New System.Windows.Forms.TextBox()
        Me.btnSave = New System.Windows.Forms.Button()
        Me.btnDisplay = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.lblCommercial = New System.Windows.Forms.Label()
        Me.lblBud = New System.Windows.Forms.Label()
        Me.lblFedEx = New System.Windows.Forms.Label()
        Me.lblETrade = New System.Windows.Forms.Label()
        Me.lblPepsi = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'lstCommercial
        '
        Me.lstCommercial.FormattingEnabled = True
        Me.lstCommercial.Location = New System.Drawing.Point(27, 45)
        Me.lstCommercial.Name = "lstCommercial"
        Me.lstCommercial.Size = New System.Drawing.Size(120, 95)
        Me.lstCommercial.TabIndex = 0
        '
        'txtBud
        '
        Me.txtBud.Location = New System.Drawing.Point(12, 212)
        Me.txtBud.Name = "txtBud"
        Me.txtBud.ReadOnly = True
        Me.txtBud.Size = New System.Drawing.Size(100, 20)
        Me.txtBud.TabIndex = 1
        '
        'txtFedEx
        '
        Me.txtFedEx.Location = New System.Drawing.Point(134, 212)
        Me.txtFedEx.Name = "txtFedEx"
        Me.txtFedEx.ReadOnly = True
        Me.txtFedEx.Size = New System.Drawing.Size(100, 20)
        Me.txtFedEx.TabIndex = 2
        '
        'txtETrade
        '
        Me.txtETrade.Location = New System.Drawing.Point(260, 212)
        Me.txtETrade.Name = "txtETrade"
        Me.txtETrade.ReadOnly = True
        Me.txtETrade.Size = New System.Drawing.Size(100, 20)
        Me.txtETrade.TabIndex = 3
        '
        'txtPepsi
        '
        Me.txtPepsi.Location = New System.Drawing.Point(375, 212)
        Me.txtPepsi.Name = "txtPepsi"
        Me.txtPepsi.ReadOnly = True
        Me.txtPepsi.Size = New System.Drawing.Size(100, 20)
        Me.txtPepsi.TabIndex = 4
        '
        'btnSave
        '
        Me.btnSave.Location = New System.Drawing.Point(293, 45)
        Me.btnSave.Name = "btnSave"
        Me.btnSave.Size = New System.Drawing.Size(127, 23)
        Me.btnSave.TabIndex = 5
        Me.btnSave.Text = "&Save Vote"
        Me.btnSave.UseVisualStyleBackColor = True
        '
        'btnDisplay
        '
        Me.btnDisplay.Location = New System.Drawing.Point(293, 74)
        Me.btnDisplay.Name = "btnDisplay"
        Me.btnDisplay.Size = New System.Drawing.Size(127, 23)
        Me.btnDisplay.TabIndex = 6
        Me.btnDisplay.Text = "&Display Votes"
        Me.btnDisplay.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(293, 103)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(127, 23)
        Me.btnExit.TabIndex = 7
        Me.btnExit.Text = "E&xit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'lblCommercial
        '
        Me.lblCommercial.AutoSize = True
        Me.lblCommercial.Location = New System.Drawing.Point(27, 26)
        Me.lblCommercial.Name = "lblCommercial"
        Me.lblCommercial.Size = New System.Drawing.Size(64, 13)
        Me.lblCommercial.TabIndex = 8
        Me.lblCommercial.Text = "&Commercial:"
        '
        'lblBud
        '
        Me.lblBud.AutoSize = True
        Me.lblBud.Location = New System.Drawing.Point(12, 193)
        Me.lblBud.Name = "lblBud"
        Me.lblBud.Size = New System.Drawing.Size(59, 13)
        Me.lblBud.TabIndex = 9
        Me.lblBud.Text = "Budweiser:"
        '
        'lblFedEx
        '
        Me.lblFedEx.AutoSize = True
        Me.lblFedEx.Location = New System.Drawing.Point(131, 193)
        Me.lblFedEx.Name = "lblFedEx"
        Me.lblFedEx.Size = New System.Drawing.Size(40, 13)
        Me.lblFedEx.TabIndex = 10
        Me.lblFedEx.Text = "FedEx:"
        '
        'lblETrade
        '
        Me.lblETrade.AutoSize = True
        Me.lblETrade.Location = New System.Drawing.Point(260, 192)
        Me.lblETrade.Name = "lblETrade"
        Me.lblETrade.Size = New System.Drawing.Size(58, 13)
        Me.lblETrade.TabIndex = 11
        Me.lblETrade.Text = "E*TRADE:"
        '
        'lblPepsi
        '
        Me.lblPepsi.AutoSize = True
        Me.lblPepsi.Location = New System.Drawing.Point(375, 191)
        Me.lblPepsi.Name = "lblPepsi"
        Me.lblPepsi.Size = New System.Drawing.Size(36, 13)
        Me.lblPepsi.TabIndex = 12
        Me.lblPepsi.Text = "Pepsi:"
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(487, 261)
        Me.Controls.Add(Me.lblPepsi)
        Me.Controls.Add(Me.lblETrade)
        Me.Controls.Add(Me.lblFedEx)
        Me.Controls.Add(Me.lblBud)
        Me.Controls.Add(Me.lblCommercial)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnDisplay)
        Me.Controls.Add(Me.btnSave)
        Me.Controls.Add(Me.txtPepsi)
        Me.Controls.Add(Me.txtETrade)
        Me.Controls.Add(Me.txtFedEx)
        Me.Controls.Add(Me.txtBud)
        Me.Controls.Add(Me.lstCommercial)
        Me.Name = "frmMain"
        Me.Text = "WKRK"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lstCommercial As ListBox
    Friend WithEvents txtBud As TextBox
    Friend WithEvents txtFedEx As TextBox
    Friend WithEvents txtETrade As TextBox
    Friend WithEvents txtPepsi As TextBox
    Friend WithEvents btnSave As Button
    Friend WithEvents btnDisplay As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents lblCommercial As Label
    Friend WithEvents lblBud As Label
    Friend WithEvents lblFedEx As Label
    Friend WithEvents lblETrade As Label
    Friend WithEvents lblPepsi As Label
End Class
