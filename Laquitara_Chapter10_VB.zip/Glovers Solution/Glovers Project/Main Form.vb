' Name:         Glovers Project
' Purpose:      Displays the price of an item
' Programmer:   <Shelby Laquitara> on <04/21/2016>

Option Explicit On
Option Strict On
Option Infer Off

Public Class frmMain
    'create the structure
    Structure Product
        Public itemNum As String
        Public price As Double
    End Structure

    Private products(4) As Product

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles Me.Load
        Dim product As Product
        Dim i As Integer = 0
        'read the item numbers and prices
        Dim inFile As IO.StreamReader
        If IO.File.Exists("ItemInfo.txt") Then
            inFile = IO.File.OpenText("ItemInfo.txt")
            Do Until inFile.Peek = -1
                product.itemNum = inFile.ReadLine
                product.price = Convert.ToDouble(inFile.ReadLine)
                products(i) = product
                i += 1
            Loop
        End If

        'using the structure
        For j As Integer = 0 To 4
            lstNumbers.Items.Add(products(j).itemNum)
        Next

    End Sub

    Private Sub lstNumbers_Click(sender As Object, e As EventArgs) Handles lstNumbers.Click

        Dim index As Integer = lstNumbers.SelectedIndex
        'the item will appear in the listbox
        lblPrice.Text = products(index).price.ToString
    End Sub
End Class